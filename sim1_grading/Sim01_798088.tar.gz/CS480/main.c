#include<stdio.h>
#include<string.h>
#include"myQueue.h"
#include"myMethods.h"

 

void main() {
	
	delimitMD();
    delimitConfig();
    checkEmpty();
    printf("------------------------\n");
    removeInt();
    Display();
    printf("------------------------\n");
    displayArray;
   
}